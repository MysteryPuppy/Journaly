# Journaly
A simple journal in your terminal.
**Commands:**
* `journaly help` for help information
* `journaly new` to create a new entry
* `journaly show` to show all logged entries

**Note:** the .txt file with all the entries is located at your home folder/journaly/entries.txt.

**Note:** Probably doesn't work on Windows. Only tested on mac. 
